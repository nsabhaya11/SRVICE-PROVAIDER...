//
//  Curentorder.h
//  servicesprovaider
//
//  Created by Admin on 14/05/17.
//  Copyright © 2017 mine. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Curentorder : UIViewController
@property (weak, nonatomic) IBOutlet UITableView *tblview;
- (IBAction)back:(id)sender;
@end
