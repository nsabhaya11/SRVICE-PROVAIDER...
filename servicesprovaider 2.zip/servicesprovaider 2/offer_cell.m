//
//  offer_cell.m
//  servicesprovaider
//
//  Created by Admin on 01/04/17.
//  Copyright © 2017 mine. All rights reserved.
//

#import "offer_cell.h"

@implementation offer_cell

- (void)awakeFromNib {
    [super awakeFromNib];
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    
}

@end
