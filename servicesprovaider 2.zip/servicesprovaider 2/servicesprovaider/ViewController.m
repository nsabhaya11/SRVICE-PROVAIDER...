//
//  ViewController.m
//  servicesprovaider
//
//  Created by MACOS on 12/19/16.
//  Copyright © 2016 mine. All rights reserved.
//

#import "ViewController.h"
#import "login.h"
#import "firstpage.h"


@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSUserDefaults *dif=[NSUserDefaults standardUserDefaults];
    NSString *str=[dif valueForKey:@"login_status"];
    if([str isEqualToString:@"1"]){
        
        firstpage*s1=[self.storyboard instantiateViewControllerWithIdentifier:@"f1"];
        
        [self.navigationController pushViewController:s1 animated:YES];
    }
    
    
    
    // Do any additional setup after loading the view, typicallyfrom a nib.
    UITapGestureRecognizer *tap=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(myfun)];
    _img_12veiw.userInteractionEnabled=YES;
    
    tap.numberOfTapsRequired=1;
    [_img_12veiw addGestureRecognizer:tap];
}
-(void)myfun
{
    login *l1=[self.storyboard instantiateViewControllerWithIdentifier:@"l1"];
    
    [self.navigationController pushViewController:l1 animated:YES];
 // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
